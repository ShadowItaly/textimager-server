#####################
Don't remove this file. The ActiveMQ launch script checks for existence of 
this file when starting the broker. 
#####################

For instructions how to lunch the broker please review README file
found in the base install directory of UIMA-AS.